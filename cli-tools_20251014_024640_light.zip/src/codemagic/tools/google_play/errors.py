from codemagic import cli


class GooglePlayError(cli.CliAppException):
    pass
