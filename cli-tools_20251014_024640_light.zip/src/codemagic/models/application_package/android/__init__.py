from .android_manifest import AndroidManifest
from .app_bundle_resources import AppBundleResources
from .strings import Strings
