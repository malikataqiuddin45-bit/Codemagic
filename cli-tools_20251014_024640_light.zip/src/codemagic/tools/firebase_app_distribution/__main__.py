if __name__ == "__main__":
    from .firebase_app_distribution import FirebaseAppDistribution

    FirebaseAppDistribution.invoke_cli()
