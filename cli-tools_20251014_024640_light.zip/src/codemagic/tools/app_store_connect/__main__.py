if __name__ == "__main__":
    from .app_store_connect import AppStoreConnect

    AppStoreConnect.invoke_cli()
