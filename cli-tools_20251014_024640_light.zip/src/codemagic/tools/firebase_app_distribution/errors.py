from codemagic import cli


class FirebaseAppDistributionError(cli.CliAppException):
    pass
