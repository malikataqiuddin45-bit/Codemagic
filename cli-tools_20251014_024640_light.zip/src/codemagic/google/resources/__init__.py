from .resource import Resource
from .resource_printer import ResourcePrinter
