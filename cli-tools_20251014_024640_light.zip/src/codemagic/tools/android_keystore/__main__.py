if __name__ == "__main__":
    from .android_keystore import AndroidKeystore

    AndroidKeystore.invoke_cli()
