from codemagic.models.enums import ResourceEnum


class OrderBy(ResourceEnum):
    CREATE_TIME_DESC = "createTimeDesc"
    CREATE_TIME_ASC = "createTime"
