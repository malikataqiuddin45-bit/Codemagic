if __name__ == "__main__":
    from .google_play import GooglePlay

    GooglePlay.invoke_cli()
