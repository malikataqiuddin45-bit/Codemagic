#!/usr/bin/env bash
set -euo pipefail

# Pastikan folder gradle wujud
mkdir -p android/gradle

# Cipta atau tambah fail gradle.properties
cat >> android/gradle/gradle.properties <<'EOF'

# === Debug-friendly on CI ===
org.gradle.console=plain
org.gradle.daemon=false
org.gradle.parallel=false
org.gradle.configureondemand=false
org.gradle.vfs.watch=false

# Kotlin compile in-process (mudah keluarkan error)
kotlin.compiler.execution.strategy=in-process
EOF

echo "✅ gradle.properties created/patched successfully."
ls -l android/gradle/gradle.properties
tail -n 10 android/gradle/gradle.properties
